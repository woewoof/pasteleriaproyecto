package com.example.proyectapplication.Utils

import com.example.proyectapplication.R
import com.example.proyectapplication.models.Producto

object DataProvider {
    val productosPrueba = listOf(
        Producto(1, "Torta Cuadrada de Chocolate", 45.000, R.drawable.tortacuadradadechocolate),
        Producto(2, "Torta Cuadrada de Frutas", 50.000, R.drawable.tortafrutillacremacuadrada),
        Producto(3, "Torta Circular de Vainilla", 40.000, R.drawable.circularvainilla),
        Producto(4, "Torta Circular de Manjar", 42.000, R.drawable.circularmanjar),
        Producto(5, "Torta Sin Azucar De Naranja", 42.000, R.drawable.tortasinazucarnaranja),
        Producto(6, "Tiramisu", 5.500, R.drawable.tiramisu)

    )

}